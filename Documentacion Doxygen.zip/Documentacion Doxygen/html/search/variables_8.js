var searchData=
[
  ['name_0',['Name',['../struct_book.html#a5e6182c030324511dd82e9fa1a0ab071',1,'Book']]],
  ['next_1',['next',['../struct_node___l_b.html#abbad42537a1a5c18feb777396d06000a',1,'Node_LB']]]
];
