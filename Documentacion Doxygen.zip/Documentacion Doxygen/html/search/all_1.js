var searchData=
[
  ['category_0',['Category',['../struct_book.html#a666df14acddd22585b7ca23d20258987',1,'Book']]]
];
