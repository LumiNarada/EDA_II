var searchData=
[
  ['book_5fcreate_0',['Book_Create',['../_book_8h.html#a287da8cbd9cdd6a1969cc0495bc3cd69',1,'Book.h']]]
];
