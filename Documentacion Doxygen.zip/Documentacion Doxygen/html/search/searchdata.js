var indexSectionsWithContent =
{
  0: "bcefhklmnpsvy",
  1: "behlnp",
  2: "behlmny",
  3: "behlmnpsy",
  4: "bcefhklmnpsv",
  5: "ln",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Estructuras de Datos",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "typedefs",
  6: "defines"
};

