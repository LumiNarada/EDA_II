var searchData=
[
  ['start_0',['Start',['../struct_list___n_b.html#af40d35eb8e194f27009a9909ab357d00',1,'List_NB']]],
  ['stock_1',['stock',['../struct_book.html#a9f6b1d8f565c649873cd57896391b2aa',1,'Book']]]
];
