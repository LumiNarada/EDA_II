var searchData=
[
  ['value_0',['value',['../struct_ele__list.html#a4e9aec275e566b978a3ccb4e043d8c61',1,'Ele_list']]]
];
