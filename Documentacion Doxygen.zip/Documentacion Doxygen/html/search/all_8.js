var searchData=
[
  ['name_0',['Name',['../struct_book.html#a5e6182c030324511dd82e9fa1a0ab071',1,'Book']]],
  ['next_1',['next',['../struct_node___l_b.html#abbad42537a1a5c18feb777396d06000a',1,'Node_LB']]],
  ['nlb_5fcreate_2',['NLB_Create',['../_node___l_b_8h.html#ac0906f3c354bdd6f4c5449822ec0c0ed',1,'Node_LB.h']]],
  ['nlb_5fprint_3',['NLB_print',['../_node___l_b_8h.html#a2622ffc1ccae57fbb68cd43d7138db52',1,'Node_LB.h']]],
  ['node_5flb_4',['Node_LB',['../struct_node___l_b.html',1,'']]],
  ['node_5flb_2eh_5',['Node_LB.h',['../_node___l_b_8h.html',1,'']]],
  ['nodelb_6',['NodeLB',['../_node___l_b_8h.html#ac3f34d1f6fd95618337d1aad7211e212',1,'Node_LB.h']]]
];
