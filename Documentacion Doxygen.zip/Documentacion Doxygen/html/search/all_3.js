var searchData=
[
  ['f_5fname_0',['F_name',['../struct_book.html#a6da5e01471d2fc3e8a2e2104ed57cabc',1,'Book']]],
  ['finish_1',['Finish',['../struct_list___n_b.html#a028fefcacd53fadd3edde5fd8596ad28',1,'List_NB']]]
];
