var searchData=
[
  ['book_0',['book',['../struct_node___l_b.html#a317ac738668f4c8da0fa3d660bffca81',1,'Node_LB']]]
];
